/* === FOXS SERVICES — MAIN JS === */
document.addEventListener('DOMContentLoaded', function () {

  // Sticky header
  const header = document.getElementById('header');
  window.addEventListener('scroll', function () {
    header && header.classList.toggle('scrolled', window.scrollY > 40);
  });

  // Mobile menu
  const hamburger = document.querySelector('.hamburger');
  const mobileMenu = document.querySelector('.mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      mobileMenu.classList.toggle('open');
    });
  }

  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (mobileMenu) mobileMenu.classList.remove('open');
      }
    });
  });

  // Counter animation
  function animateCounter(el) {
    const target = parseInt(el.dataset.target || el.innerText, 10);
    if (isNaN(target)) return;
    const suffix = el.dataset.suffix || '';
    const prefix = el.dataset.prefix || '';
    let current = 0;
    const duration = 1800;
    const step = target / (duration / 16);
    const timer = setInterval(function () {
      current = Math.min(current + step, target);
      el.textContent = prefix + Math.floor(current) + suffix;
      if (current >= target) clearInterval(timer);
    }, 16);
  }

  const counters = document.querySelectorAll('[data-counter]');
  if (counters.length) {
    const obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    counters.forEach(function (c) { obs.observe(c); });
  }

  // Contact form
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const status = document.getElementById('formStatus');
      const btn = contactForm.querySelector('button[type="submit"]');
      const data = new FormData(contactForm);
      data.append('action', 'foxs_contact');
      data.append('nonce', (window.foxsAjax && window.foxsAjax.nonce) || '');
      btn.disabled = true;
      btn.textContent = 'Sending...';
      fetch((window.foxsAjax && window.foxsAjax.ajaxurl) || '/wp-admin/admin-ajax.php', {
        method: 'POST', body: data
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          status.textContent = res.data && res.data.message ? res.data.message : (res.success ? 'Message sent!' : 'Error. Please try again.');
          status.className = 'form-status ' + (res.success ? 'success' : 'error');
          if (res.success) contactForm.reset();
        })
        .catch(function () {
          status.textContent = 'Error sending. Please call us directly.';
          status.className = 'form-status error';
        })
        .finally(function () {
          btn.disabled = false;
          btn.textContent = 'Send Message';
        });
    });
  }

  // Inquiry forms (service pages)
  document.querySelectorAll('.inquiry-form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const status = form.querySelector('.form-status');
      const btn = form.querySelector('button[type="submit"]');
      const data = new FormData(form);
      data.append('action', 'foxs_inquiry');
      data.append('nonce', (window.foxsAjax && window.foxsAjax.nonce) || '');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending...'; }
      fetch((window.foxsAjax && window.foxsAjax.ajaxurl) || '/wp-admin/admin-ajax.php', {
        method: 'POST', body: data
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (status) {
            status.textContent = res.data && res.data.message ? res.data.message : (res.success ? 'Inquiry sent!' : 'Error. Please try again.');
            status.className = 'form-status ' + (res.success ? 'success' : 'error');
          }
          if (res.success) form.reset();
        })
        .catch(function () {
          if (status) { status.textContent = 'Error. Please email nicky@profoxus.com'; status.className = 'form-status error'; }
        })
        .finally(function () {
          if (btn) { btn.disabled = false; btn.textContent = 'Submit Inquiry'; }
        });
    });
  });

});
