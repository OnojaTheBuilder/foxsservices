<?php
/**
 * Shared service page helpers
 */

function foxs_inquiry_form($service_name = '') {
    ob_start(); ?>
    <div class="sidebar-card">
      <h3>Request a Quote</h3>
      <form class="inquiry-form" novalidate>
        <?php wp_nonce_field('foxs_contact_nonce', 'nonce'); ?>
        <input type="hidden" name="inquiry_service" value="<?php echo esc_attr($service_name); ?>">
        <div class="form-group">
          <label>Your Name *</label>
          <input type="text" name="inquiry_name" placeholder="Full name" required>
        </div>
        <div class="form-group">
          <label>Email *</label>
          <input type="email" name="inquiry_email" placeholder="your@email.com" required>
        </div>
        <div class="form-group">
          <label>Phone</label>
          <input type="tel" name="inquiry_phone" placeholder="+1 (555) 000-0000">
        </div>
        <div class="form-group">
          <label>Company</label>
          <input type="text" name="inquiry_company" placeholder="Your company">
        </div>
        <div class="form-group">
          <label>Message *</label>
          <textarea name="inquiry_message" rows="4" placeholder="Describe the equipment you need..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit Inquiry</button>
        <p class="form-status"></p>
      </form>
    </div>
    <?php return ob_get_clean();
}

function foxs_other_services($exclude = '') {
    $services = [
        'Chemical Equipment'        => home_url('/chemical-equipment'),
        'Converting Equipment'      => home_url('/converting-equipment'),
        'Edible Oils &amp; Fishmeal'=> home_url('/edible-oils-fishmeal'),
        'Pharmaceutical Equipment'  => home_url('/pharmaceutical-equipment'),
        'Plastics Equipment'        => home_url('/plastics-equipment'),
        'Power Generation'          => home_url('/power-generation'),
        'Pulp and Paper'            => home_url('/pulp-and-paper'),
    ];
    ob_start(); ?>
    <div class="other-services">
      <h3>Other Equipment Categories</h3>
      <div class="other-services-list">
        <?php foreach ($services as $name => $url):
          if (strip_tags($name) === $exclude) continue; ?>
          <a href="<?php echo esc_url($url); ?>"><?php echo $name; ?> <span>&rarr;</span></a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php return ob_get_clean();
}
